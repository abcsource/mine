#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(int ae,char *arg[])
{
	

	int a=0,b=0;	
	cps(&a,&b);
	printf(1," \n%d %d\n",a,b);
	exit();
}

