#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char *argv[])
{
	/* code */
	if(argc != 3)	{
		printf(1, "Error in number of arguments\n");
		exit();
	}
	else
	{
		int fd1, fd2;

		printf(1, "%s %s\n", argv[1], argv[2]);

		do
		{
			fd1 = open(argv[1], O_RDONLY);
			printf(1, "%d\n", fd1);
		}while(fd1==-1);

		do{

			fd2 = open(argv[2], O_WRONLY|O_CREATE);
		}while(fd2==-1);
		char str[100];
		read(fd1, str, 100);
			printf(1,"recieved string: %s\n", str);
			write(fd2, str, 100);
		printf(1, "done\n");
		close(fd1);
		close(fd2);
		exit();
	}
	return 0;
}

