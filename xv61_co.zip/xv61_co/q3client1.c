#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
#include<sys/types.h>
#include <sys/stat.h>
#include<fcntl.h>
char  MSG[] = "Hello There, How do you do??";
char in[50];

int main(int argc, char const *argv[])
{
	int fd1 = -1;
	do
	{
		fd1=open("WELL_KNOWN",O_WRONLY);
		printf("Tryn..\n");
		sleep(1);
	}while(fd1==-1);
	printf("Writing the MSG\n");
	write(fd1,MSG,50);
	close(fd1);
	unlink("PIPE_1");
	mknod("PIPE_1",S_IFIFO,0);
	chmod("PIPE_1",0777);
	int fd2 = open("PIPE_1",O_RDONLY);
	printf("Reading\n");
	while(1) {read(fd2,in,50); printf("%s\n",in ),sleep(1);};
	close(fd2);
	return 0;
}