#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
#include<sys/types.h>
#include <sys/stat.h>
#include<fcntl.h>

#define NUM 2

int fd_arr[NUM];
char * pipes[] = {"PIPE_1","PIPE_2"}; 
char  MSG[50];
int main()
{

        unlink("WELL_KNOWN");
        mknod("WELL_KNOWN",S_IFIFO,0);
        chmod("WELL_KNOWN",0777);
        int fd = open("WELL_KNOWN",O_RDONLY);
        printf("Created the Read Pipe\n");
        printf("Listening .... \n");
        while(1)
        {
                read(fd,MSG,50);
                //close(fd);
                printf("Got the message .. %s\n",MSG);
                printf("Oening the writing pipes\n");
                for (int i = 0; i < NUM; ++i)
                {
                        fd_arr[i] = -1;
                        do
                        {
                                fd_arr[i] = open(pipes[i],O_WRONLY);
                                sleep(1);
                                printf("Tryn for %d\n",i );
                        }
                        while(fd_arr[i]==-1);
                        printf("Echoing to %d.....\n", i);
                        write(fd_arr[i],MSG,50);
                        close(fd_arr[i]);
                }
        }


        return 0;
}
