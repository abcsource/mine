#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(int a,char *arg[])
{
	cps();
	exit();
}

