#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int main(int argc, char *argv[])
{
	/* code */

	cps();

	printf(1,"Total number of process = %d\n", getnumproc());

	printf(1, "Maximum pid of process is %d\n", getmaxpid());

	exit();
	
	return 0;
}