#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int 
main()

{
	int a,b;
	cps(&a,&b);
	printf(1,"%d %d\n",a,b);
	exit();
}
