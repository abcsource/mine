#include<stdio.h>
#include"a.h"

int fun(){
	printf("Hello Calledhgdfhfk");
	return 0;
}
