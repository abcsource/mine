#include<stdio.h>
#include"a.h"

int main(){

	fun();
	return 0;
}
